//
//  WebRegisterController.h
//  disappear
//
//  Created by CpyShine on 13-6-20.
//  Copyright (c) 2013年 CpyShine. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebRegisterController : UIViewController<UIWebViewDelegate,UIAlertViewDelegate>

{
    UIAlertView * m_alertView;
}

@end
